import os
import subprocess
from django.conf import settings
from django.shortcuts import render, redirect
from .models import UserRegistrationModel
from django.contrib import messages

def UserRegisterActions(request):
    if request.method == 'POST':
        user = UserRegistrationModel(
            name=request.POST['name'],
            loginid=request.POST['loginid'],
            password=request.POST['password'],
            mobile=request.POST['mobile'],
            email=request.POST['email'],
            locality=request.POST['locality'],
            address=request.POST['address'],
            city=request.POST['city'],
            state=request.POST['state'],
            status='waiting'
        )
        user.save()
        messages.success(request,"Registration successful!")
    return render(request, 'UserRegistrations.html') 


def UserLoginCheck(request):
    if request.method == "POST":
        loginid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("Login ID = ", loginid, ' Password = ', pswd)
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            status = check.status
            print('Status is = ', status)
            if status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                data = {'loginid': loginid}
                print("User id At", check.id, status)
                return render(request, 'users/UserHomePage.html', {})
            else:
                messages.success(request, 'Your Account Not at activated')
                return render(request, 'UserLogin.html')
        except Exception as e:
            print('Exception is ', str(e))
            pass
        messages.success(request, 'Invalid Login id and password')
    return render(request, 'UserLogin.html', {})

def UserHome(request):
    return render(request, 'users/UserHomePage.html', {})


def index(request):
    return render(request,"index.html")

import random
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib import messages
from .models import UserRegistrationModel

otp_storage = {}  # Temporary dictionary to store OTPs

def send_otp(email):
    otp = random.randint(100000, 999999)  # Generate a 6-digit OTP
    otp_storage[email] = otp

    subject = "Password Reset OTP"
    message = f"Your OTP for password reset is: {otp}"
    from_email = "saikumardatapoint1@gmail.com"  # Change this to your email
    send_mail(subject, message, from_email, [email])

    return otp

def forgot_password(request):
    if request.method == "POST":
        email = request.POST.get("email")

        if UserRegistrationModel.objects.filter(email=email).exists():
            send_otp(email)
            request.session["reset_email"] = email  # Store email in session
            return redirect("verify_otp")
        else:
            messages.error(request, "Email not registered!")

    return render(request, "users/forgot_password.html")

def verify_otp(request):
    if request.method == "POST":
        otp_entered = request.POST.get("otp")
        email = request.session.get("reset_email")

        if otp_storage.get(email) and str(otp_storage[email]) == otp_entered:
            return redirect("reset_password")
        else:
            messages.error(request, "Invalid OTP!")

    return render(request, "users/verify_otp.html")

def reset_password(request):
    if request.method == "POST":
        new_password = request.POST.get("new_password")
        email = request.session.get("reset_email")

        if UserRegistrationModel.objects.filter(email=email).exists():
            user = UserRegistrationModel.objects.get(email=email)
            user.password = new_password  # Updating password
            user.save()
            messages.success(request, "Password reset successful! Please log in.")
            return redirect("UserLoginCheck")

    return render(request, "users/reset_password.html")

virtual_mouse_process = None
def gesture(request):
    global virtual_mouse_process
    if request.method == "POST":
        # If not already running, start the virtual mouse
        if virtual_mouse_process is None or virtual_mouse_process.poll() is not None:
            script_path = os.path.join(settings.BASE_DIR, 'virtual_mouse.py')
            virtual_mouse_process = subprocess.Popen(["python", script_path])
    
    elif request.method == "GET" and request.GET.get("stop") == "1":
        # Stop the virtual mouse if running
        if virtual_mouse_process and virtual_mouse_process.poll() is None:
            virtual_mouse_process.terminate()
            virtual_mouse_process = None
        return redirect('UserHome')
    return render(request, 'users/gesture.html')


def overview(request):
    return render(request, 'users/overview.html')


# Medical Data Management Views
from .models import Patient, MedicalRecord
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse

@login_required
def patient_profile(request):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    try:
        patient = Patient.objects.get(user=user)
    except Patient.DoesNotExist:
        patient = None

    if request.method == 'POST':
        if patient:
            # Update existing patient profile
            patient.date_of_birth = request.POST['date_of_birth']
            patient.gender = request.POST['gender']
            patient.blood_type = request.POST.get('blood_type', '')
            patient.emergency_contact_name = request.POST['emergency_contact_name']
            patient.emergency_contact_phone = request.POST['emergency_contact_phone']
            patient.emergency_contact_relationship = request.POST['emergency_contact_relationship']
            patient.medical_conditions = request.POST.get('medical_conditions', '')
            patient.allergies = request.POST.get('allergies', '')
            patient.current_medications = request.POST.get('current_medications', '')
            patient.save()
            messages.success(request, 'Patient profile updated successfully!')
        else:
            # Create new patient profile
            patient = Patient.objects.create(
                user=user,
                date_of_birth=request.POST['date_of_birth'],
                gender=request.POST['gender'],
                blood_type=request.POST.get('blood_type', ''),
                emergency_contact_name=request.POST['emergency_contact_name'],
                emergency_contact_phone=request.POST['emergency_contact_phone'],
                emergency_contact_relationship=request.POST['emergency_contact_relationship'],
                medical_conditions=request.POST.get('medical_conditions', ''),
                allergies=request.POST.get('allergies', ''),
                current_medications=request.POST.get('current_medications', '')
            )
            messages.success(request, 'Patient profile created successfully!')

    context = {'patient': patient}
    return render(request, 'users/patient_profile.html', context)

@login_required
def medical_records(request):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    try:
        patient = Patient.objects.get(user=user)
        records = MedicalRecord.objects.filter(patient=patient)
    except Patient.DoesNotExist:
        patient = None
        records = []

    context = {'patient': patient, 'records': records}
    return render(request, 'users/medical_records.html', context)

@login_required
def add_medical_record(request):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    try:
        patient = Patient.objects.get(user=user)
    except Patient.DoesNotExist:
        messages.error(request, 'Please create your patient profile first.')
        return redirect('patient_profile')

    if request.method == 'POST':
        record = MedicalRecord.objects.create(
            patient=patient,
            record_type=request.POST['record_type'],
            title=request.POST['title'],
            description=request.POST['description'],
            doctor_name=request.POST['doctor_name'],
            hospital_clinic=request.POST['hospital_clinic'],
            date_of_visit=request.POST['date_of_visit'],
            follow_up_date=request.POST.get('follow_up_date', None) or None,
            attachments=request.FILES.get('attachments'),
            notes=request.POST.get('notes', '')
        )
        messages.success(request, 'Medical record added successfully!')
        return redirect('medical_records')

    return render(request, 'users/add_medical_record.html')

@login_required
def view_medical_record(request, record_id):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    record = get_object_or_404(MedicalRecord, id=record_id, patient__user=user)

    context = {'record': record}
    return render(request, 'users/view_medical_record.html', context)

@login_required
def edit_medical_record(request, record_id):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    record = get_object_or_404(MedicalRecord, id=record_id, patient__user=user)

    if request.method == 'POST':
        record.record_type = request.POST['record_type']
        record.title = request.POST['title']
        record.description = request.POST['description']
        record.doctor_name = request.POST['doctor_name']
        record.hospital_clinic = request.POST['hospital_clinic']
        record.date_of_visit = request.POST['date_of_visit']
        record.follow_up_date = request.POST.get('follow_up_date', None) or None
        if request.FILES.get('attachments'):
            record.attachments = request.FILES['attachments']
        record.notes = request.POST.get('notes', '')
        record.save()
        messages.success(request, 'Medical record updated successfully!')
        return redirect('medical_records')

    context = {'record': record}
    return render(request, 'users/edit_medical_record.html', context)

@login_required
def delete_medical_record(request, record_id):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('UserLogin')

    user = get_object_or_404(UserRegistrationModel, id=user_id)
    record = get_object_or_404(MedicalRecord, id=record_id, patient__user=user)
    record.delete()
    messages.success(request, 'Medical record deleted successfully!')
    return redirect('medical_records')