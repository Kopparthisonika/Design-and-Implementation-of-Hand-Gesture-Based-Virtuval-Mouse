from django.db import models

class UserRegistrationModel(models.Model):
    name = models.CharField(max_length=100)
    loginid = models.CharField(unique=True, max_length=100)
    password = models.CharField(max_length=100)
    mobile = models.CharField(unique=True, max_length=10)  # Adjusted max_length to 10 for mobile numbers
    email = models.EmailField(unique=True, max_length=100)  # Use EmailField for better validation
    locality = models.CharField(max_length=100)
    address = models.TextField(max_length=1000)  # Use TextField for longer addresses
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    status = models.CharField(max_length=100, default='waiting')

    def __str__(self):
        return self.loginid

    class Meta:
        db_table = 'user_registrations'


class Patient(models.Model):
    user = models.OneToOneField(UserRegistrationModel, on_delete=models.CASCADE)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    blood_type = models.CharField(max_length=5, choices=[
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-')
    ], blank=True, null=True)
    emergency_contact_name = models.CharField(max_length=100)
    emergency_contact_phone = models.CharField(max_length=10)
    emergency_contact_relationship = models.CharField(max_length=50)
    medical_conditions = models.TextField(blank=True, null=True)
    allergies = models.TextField(blank=True, null=True)
    current_medications = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.name} - Patient Profile"

    class Meta:
        db_table = 'patients'


class MedicalRecord(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    record_type = models.CharField(max_length=50, choices=[
        ('Consultation', 'Consultation'),
        ('Diagnosis', 'Diagnosis'),
        ('Treatment', 'Treatment'),
        ('Prescription', 'Prescription'),
        ('Lab Results', 'Lab Results'),
        ('Imaging', 'Imaging'),
        ('Surgery', 'Surgery'),
        ('Other', 'Other')
    ])
    title = models.CharField(max_length=200)
    description = models.TextField()
    doctor_name = models.CharField(max_length=100)
    hospital_clinic = models.CharField(max_length=100)
    date_of_visit = models.DateField()
    follow_up_date = models.DateField(blank=True, null=True)
    attachments = models.FileField(upload_to='medical_records/', blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.patient.user.name} - {self.title} ({self.date_of_visit})"

    class Meta:
        db_table = 'medical_records'
        ordering = ['-date_of_visit']

